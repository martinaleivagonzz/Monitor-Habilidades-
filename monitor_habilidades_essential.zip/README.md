Para activar el entorno, ejecuta en el terminal: 
conda activate monitor_habilidades 
y luego ejecuta :
streamlit run dashboard.py 

💡 INSTRUCCIONES:
1. Para ejecutar el proyecto: python main.py
2. Para modo rápido: python main.py --rapido
3. Asegúrate de estar en: /Users/paulinagonzalez/python/monitor_habilidades/
(venv) (monitor_habilidades) paulinagonzalez@iMac monitor_habilidades % 

