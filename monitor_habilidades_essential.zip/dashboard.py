import streamlit as st
import pandas as pd
import json
import os
import plotly.express as px
from scoring import calculate_scoring, generate_recommendations, load_user_profile

# ==============================
# CONFIGURACIÓN GLOBAL
# ==============================
st.set_page_config(
    page_title="Monitor de Habilidades",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ==============================
# ESTILO GLOBAL
# ==============================
st.markdown("""
    <style>
        body, .stApp {
            background-color: #ffffff;
            color: #1a1a1a;
            font-family: 'Inter', sans-serif;
        }
        h1, h2, h3, h4 {
            color: #111111;
            font-weight: 600;
        }
        .stButton>button {
            background-color: #2b7cff;
            color: white;
            border-radius: 8px;
            padding: 0.6em 1.2em;
            border: none;
            font-size: 15px;
            transition: 0.3s;
        }
        .stButton>button:hover {
            background-color: #1a66e6;
        }
        hr {border: 0; border-top: 1px solid #e6e6e6; margin: 1.5em 0;}
        .title {
            font-size: 2.4em;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 0.3em;
        }
        .subtitle {
            color: #475569;
            font-size: 1.1em;
            margin-bottom: 1em;
        }
    </style>
""", unsafe_allow_html=True)


# ==============================
# FUNCIONES AUXILIARES
# ==============================
def save_user_profile(profile_data, user_id):
    os.makedirs("data/users", exist_ok=True)
    with open(f"data/users/{user_id}.json", "w", encoding="utf-8") as f:
        json.dump(profile_data, f, indent=4, ensure_ascii=False)


def load_trending_skills():
    """
    Carga las habilidades más demandadas desde matriz_competencias.csv.
    Si no existe o está mal, usa un DataFrame por defecto.
    """
    try:
        df = pd.read_csv("data/processed/matriz_competencias.csv")
        if not {"skill", "porcentaje_mercado"}.issubset(df.columns):
            raise ValueError("Columnas incorrectas")
        df = df.rename(columns={"porcentaje_mercado": "porcentaje"})
        df = df[["skill", "porcentaje"]]
        df = df.sort_values("porcentaje", ascending=False)
    except Exception as e:
        print("⚠️ Error cargando matriz_competencias.csv:", e)
        df = pd.DataFrame({
            "skill": ["Python", "SQL", "Power BI", "Machine Learning", "Excel", "Tableau"],
            "porcentaje": [95, 89, 84, 80, 77, 73]
        })
    return df


# ==============================
# PÁGINA: INICIO
# ==============================
def pagina_inicio():
    # CSS MEJORADO SIN ANIMACIONES PROBLEMÁTICAS
    st.markdown("""
        <style>
            .hero-container {
                position: relative;
                width: 100%;
                margin: 2em 0;
                text-align: center;
            }
            
            .hero-img {
                width: 90%;
                max-width: 1000px;
                border-radius: 18px;
                opacity: 0.88;
                box-shadow: 0 8px 25px rgba(0,0,0,0.15);
                transition: all 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94);
                display: block;
                margin: 0 auto;
            }
            
            .hero-img:hover {
                transform: scale(1.02);
                opacity: 0.95;
                box-shadow: 0 12px 35px rgba(0,0,0,0.2);
            }
            
            .chart-container {
                background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
                border-radius: 16px;
                padding: 2rem;
                box-shadow: 0 8px 30px rgba(0,0,0,0.08);
                border: 1px solid #f1f5f9;
                margin: 2rem 0;
            }
            
            .gradient-text {
                background: linear-gradient(135deg, #1e293b 0%, #475569 100%);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-clip: text;
            }
            
            .gradient-accent {
                background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-clip: text;
            }
        </style>
    """, unsafe_allow_html=True)

    # ENCABEZADO SIN ANIMACIONES CSS PROBLEMÁTICAS
    st.markdown("""
        <h1 style='font-weight:800; font-size:2.8rem; text-align:center; margin-bottom:1rem;'>
            <span class='gradient-text'>🚀 Monitor de Habilidades Profesionales</span>
        </h1>
    """, unsafe_allow_html=True)
    
    st.markdown("""
        <p style='color:#64748b; font-size:1.2rem; text-align:center; max-width:800px; margin:0 auto 3rem auto; line-height:1.6;'>
            Evalúa tus competencias, identifica brechas y descubre oportunidades de crecimiento profesional
        </p>
    """, unsafe_allow_html=True)

    # IMAGEN HERO
    st.markdown("""
        <div class='hero-container'>
            <img src='https://cdn.pixabay.com/photo/2020/05/07/19/37/dashboard-5144281_1280.jpg' class='hero-img' alt='Dashboard Analytics'>
        </div>
    """, unsafe_allow_html=True)

    # SECCIÓN DEL GRÁFICO
    st.markdown("""
        <div>
            <h2 style='text-align:center; font-size:2rem; color:#1e293b; margin:3rem 0 2rem 0;'>
                📊 Tendencias 2025 — <span class='gradient-accent'>Habilidades más demandadas</span>
            </h2>
        </div>
    """, unsafe_allow_html=True)

    # GRÁFICO SIMPLIFICADO (USA TU load_trending_skills() ORIGINAL)
    df_trend = load_trending_skills()

    # GRÁFICO PLOTLY MÍNIMO Y SEGURO
    with st.container():
        st.markdown('<div class="chart-container">', unsafe_allow_html=True)
        
        fig = px.bar(
            df_trend,
            x="skill",
            y="porcentaje", 
            color="porcentaje",
            color_continuous_scale="Blues",
            title="Distribución de Demanda de Habilidades"
        )
        
        fig.update_layout(
            showlegend=False,
            xaxis_tickangle=-45,
            height=500
        )
        
        st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})
        st.markdown('</div>', unsafe_allow_html=True)

    # FOOTER
    st.markdown("""
        <p style='text-align:center; color:#94a3b8; margin-top:3rem; font-size:0.9rem; padding:1rem; border-top:1px solid #f1f5f9;'>
            🚀 Datos simulados para análisis académico — <strong>Versión Estable 1.0</strong>
        </p>
    """, unsafe_allow_html=True)

# ==============================
# PÁGINA: PERFIL
# ==============================
def pagina_perfil():
    st.markdown("<div class='title'>Tu Perfil Profesional</div>", unsafe_allow_html=True)
    st.write("Completa los datos para personalizar tus resultados:")

    user_id = st.text_input("Identificador de usuario", placeholder="Ejemplo: paula01")
    nombre = st.text_input("Nombre completo", placeholder="Ejemplo: Paula González")
    experiencia = st.selectbox("Nivel de experiencia", ["Junior", "Semi-Senior", "Senior"])
    objetivo = st.text_area("Objetivo profesional", placeholder="Describe tus metas...")

    habilidades = st.multiselect(
        "Selecciona tus habilidades actuales",
        options=[
            "Python", "SQL", "Power BI", "Excel", "Tableau", "Machine Learning",
            "Análisis de Datos", "Gestión de Proyectos", "SAP", "Oracle",
            "Scrum", "Business Intelligence", "Estadística", "Comunicación", "Liderazgo"
        ],
        default=[]
    )

    if st.button("Guardar Perfil"):
        if not user_id or not nombre or len(habilidades) == 0:
            st.error("Por favor completa todos los campos requeridos.")
        else:
            data = {
                "nombre": nombre,
                "experiencia": experiencia,
                "objetivo": objetivo,
                "habilidades": habilidades
            }
            save_user_profile(data, user_id)
            st.success(f"Perfil guardado correctamente para '{user_id}'.")

    st.divider()
    st.subheader("⚙️ Cálculo de Scoring")
    user_calc = st.text_input("Ingresa el ID de usuario para generar el análisis:")

    if st.button("Calcular Scoring"):
        try:
            profile = load_user_profile(user_calc)
            df = calculate_scoring(profile)
            generate_recommendations(profile, df)
            st.success("✅ Scoring generado correctamente. Revisa el panel *Dashboard*.")
        except Exception as e:
            st.error(f"Ocurrió un error: {e}")


# ==============================
# PÁGINA: DASHBOARD
# ==============================
def pagina_dashboard():
    st.markdown("<div class='title'>Panel de Análisis</div>", unsafe_allow_html=True)
    st.write("Visualiza tus resultados y recomendaciones personalizadas.")

    user_id = st.text_input("Ingresa tu ID de usuario:")
    if st.button("Mostrar resultados"):
        try:
            df = pd.read_csv("data/processed/skills_by_seniority.csv")
            st.dataframe(df, use_container_width=True)
        except FileNotFoundError:
            st.error("❌ No se encontró el archivo de resultados. Ejecuta el cálculo de scoring primero.")
        except pd.errors.EmptyDataError:
            st.warning("⚠️ El archivo de datos está vacío. Revisa el cálculo de scoring.")


# ==============================
# PÁGINA: ACERCA DE
# ==============================
def pagina_acerca():
    st.markdown("<div class='title'>Acerca del Proyecto</div>", unsafe_allow_html=True)
    st.markdown("""
    Este monitor analiza tu perfil profesional y recomienda rutas de aprendizaje personalizadas.  
    Desarrollado con **Python**, **Streamlit** y **Plotly**, inspirado en experiencias visuales tipo Coursera.
    """)


# ==============================
# NAVEGACIÓN LATERAL
# ==============================
st.sidebar.title("Navegación")
pagina = st.sidebar.radio("Ir a:", ["Inicio", "Perfil", "Dashboard", "Acerca de"])

if pagina == "Inicio":
    pagina_inicio()
elif pagina == "Perfil":
    pagina_perfil()
elif pagina == "Dashboard":
    pagina_dashboard()
else:
    pagina_acerca()


    














